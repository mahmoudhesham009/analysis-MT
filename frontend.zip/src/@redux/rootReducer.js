import { combineReducers } from 'redux';
// *** REDUCERS ***
import authenticationReducer from '@redux/reducers/authentication-reducer'
import analysisReducers from '@redux/reducers/analysis-reducers'

const rootReducer = combineReducers({
    authentication: authenticationReducer,
    analysis: analysisReducers
})



export default rootReducer
