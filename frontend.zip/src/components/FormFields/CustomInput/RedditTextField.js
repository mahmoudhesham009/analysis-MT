import React, { useMemo, Component } from 'react'
import _ from 'lodash';
import PropTypes from 'prop-types';
import { FormControl, TextField, FormHelperText } from '@mui/material'
// *** styles ***
import { styled } from '@mui/material/styles';
import { RedditTextFieldStyles } from 'assets/styles/components/FormFields/customInput.style';
import { useTheme } from 'react-jss';



/**
 * @author Na'oum Haddad <mailto:e.naoumhaddad@outlook.com> 
 * @type {Predicate}
 * @param {{
 *  type: "text" | "password";
 *  variant: "filled" | "outlined" | "standard"; 
 *  margin: "dense" | "none" | "normal"
 *  size: "small" | "medium"
 * }} props Props for the component 
 */
class RedditTextField extends Component {
    shouldComponentUpdate(nextProps, nextState) {
        const THIS_DOT_PROPS_WHITE_LIST = _.omit(this.props, ['startAdornment', 'endAdornment'])
        const NEXT_PROPS_WHITE_LIST = _.omit(nextProps, ['startAdornment', 'endAdornment'])
        return !_.isEqual(THIS_DOT_PROPS_WHITE_LIST, NEXT_PROPS_WHITE_LIST)
    }


    render() {
        const { name, type, value, variant, margin, labelText, readOnly, fullWidth, required, autoComplete, error, size, disabled, helperText, onChange, onBlur, className, startAdornment, endAdornment } = this.props
        return (
            <FormControl
                error={error}
                fullWidth={fullWidth}
                margin={margin}
                disabled={disabled}
                size={size}
                required={required}
            >
                <RedditTextFieldEl
                    type={type}
                    error={error}
                    variant={variant}
                    name={name}
                    label={labelText}
                    value={value}
                    onChange={onChange}
                    onBlur={onBlur}
                    autoComplete={autoComplete}
                    className={className}
                    InputProps={{
                        disabled: disabled,
                        readOnly: readOnly,
                        startAdornment: startAdornment,
                        endAdornment: endAdornment,
                        disableUnderline: true
                    }}
                />
                {
                    helperText && (
                        <FormHelperText>
                            {helperText}
                        </FormHelperText>
                    )
                }
            </FormControl>
        )
    }
}


function RedditTextFieldEl(props) {
    const systemTheme = useTheme()
    const Element = useMemo(() => {
        return styled((props) => <TextField {...props} />)(({ theme }) => RedditTextFieldStyles({ theme, systemTheme }))
    }, [])

    return (
        <Element {...props} />
    )
}


RedditTextField.defaultProps = {
    type: "text",
    variant: "filled",
    margin: "normal",
    readOnly: false,
    size: "small",
    className: ""
}

RedditTextField.propTypes = {
    name: PropTypes.string,
    type: PropTypes.oneOf(["text", "password"]),
    value: PropTypes.string,
    variant: PropTypes.oneOf(["filled", "outlined", "standard"]),
    margin: PropTypes.oneOf(["dense", "none", "normal"]),
    labelText: PropTypes.string,
    readOnly: PropTypes.bool,
    fullWidth: PropTypes.bool,
    required: PropTypes.bool,
    autoComplete: PropTypes.string,
    error: PropTypes.bool,
    size: PropTypes.oneOf(["small", "medium"]),
    disabled: PropTypes.bool,
    helperText: PropTypes.string,
    onChange: PropTypes.func,
    onBlur: PropTypes.func,
    className: PropTypes.string,
    startAdornment: PropTypes.any,
    endAdornment: PropTypes.any,
}


export default React.memo(RedditTextField)