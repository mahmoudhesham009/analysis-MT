import React from 'react'
import PropTypes from 'prop-types'
import Button from '@mui/material/Button'

// *** styles ***
import styles from 'assets/styles/components/FormFields/customButton.styles'
import { createUseStyles } from 'react-jss'
const useStyles = createUseStyles(styles)


/** 
 * @author Na'oum Haddad <mailto:e.naoumhaddad@outlook.com>
 * @type {Predicate} 
 * @param {{
 *  size: "small" | "medium" | "large";
 *  variant: "text" | "outlined" | "contained";
 *  color: "inherit" | "primary" | "secondary" | "success" | "error" | "info" | "warning";
 * }} props Props for the component 
 */
function CustomButton({ type, innerContent, disabled, disableFocusRipple, fullWidth, size, variant, color, startIcon, endIcon }) {

    const classes = useStyles()
    const buttonClasses = {
        // *** variant: text ***
        textPrimary: classes.textPrimary,
        textSuccess: classes.textSuccess,
        textError: classes.textError,
        textInfo: classes.textInfo,
        textWarning: classes.textWarning,
        // *** variant: outlined ***
        outlinedPrimary: classes.outlinedPrimary,
        outlinedSecondary: classes.outlinedSecondary,
        outlinedSuccess: classes.outlinedSuccess,
        outlinedError: classes.outlinedError,
        outlinedInfo: classes.outlinedInfo,
        outlinedWarning: classes.outlinedWarning,
        // *** variant: contained ***
        containedPrimary: classes.containedPrimary,
        containedSuccess: classes.containedSuccess,
        containedInfo: classes.containedInfo,
        containedError: classes.containedError,
        containedWarning: classes.containedWarning,
        // *** disabled ***
        disabled: variant === "contained" && color === "primary" ? classes.disabled : ""
    }

    // console.log(`%c --- Render Custom Button ${innerContent}`, "color: #dd00e1");
    // console.log("=================================================");

    return (
        <Button
            type={type}
            disabled={disabled}
            disableFocusRipple={disableFocusRipple}
            fullWidth={fullWidth}
            size={size}
            variant={variant}
            color={color}
            startIcon={startIcon}
            endIcon={endIcon}
            classes={buttonClasses}
        >
            {innerContent}
        </Button>
    )
}

CustomButton.defaultProps = {
    size: "medium",
    variant: "contained",
    color: "primary"
}


CustomButton.propTypes = {
    type: PropTypes.string,
    innerContent: PropTypes.node.isRequired,
    disabled: PropTypes.bool,
    disableFocusRipple: PropTypes.bool,
    fullWidth: PropTypes.bool,
    size: PropTypes.oneOf(['small', 'medium', 'large']),
    variant: PropTypes.oneOf(['text', 'outlined', 'contained']),
    color: PropTypes.oneOf(['inherit', 'primary', 'secondary', 'success', 'error', 'info', 'warning']),
    startIcon: PropTypes.node,
    endIcon: PropTypes.node
}

export default React.memo(CustomButton)
