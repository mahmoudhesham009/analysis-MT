import React from 'react'
import PropTypes from 'prop-types'
import { FormControlLabel, Checkbox } from '@mui/material';
// *** styles ***
import commonStyles from 'assets/styles/components/FormFields/common.styles'
import { createUseStyles } from 'react-jss'
const useCommonStyles = createUseStyles(commonStyles)

/**
 * @author Na'oum Haddad <mailto:e.naoumhaddad@outlook.com>
 * @type {Predicate} 
 * @param {{ 
 * labelPlacement: "end" | "start" | "top" | "bottom";
 * size: "small" | "medium" | "large";
 * }} props Props for the component
 */
const CustomCheckbox = React.forwardRef(({ name, ariaLabel, labelText, labelPlacement, size, checked, disabled, disableTypography, value, error, onChange }, ref) => {
    const commonClasses = useCommonStyles()

    if (labelText) return (
        <FormControlLabel
            name={name}
            label={labelText}
            labelPlacement={labelPlacement}
            checked={checked}
            disabled={disabled}
            inputRef={ref}
            disableTypography={disableTypography}
            value={value}
            onChange={onChange}
            classes={{
                label: error ? commonClasses.themeColorError : "",
                error: commonClasses.themeColorError
            }}
            control={
                <Checkbox
                    size={size}
                    inputProps={{ 'aria-label': ariaLabel }}
                    classes={{
                        root: error ? commonClasses.themeColorError : "",
                        colorPrimary: commonClasses.themeColorPrimary,
                        error: commonClasses.themeColorError
                    }}
                />
            }
        />
    )
    else return (
        <Checkbox
            size={size}
            inputRef={ref}
            checked={checked}
            disabled={disabled}
            value={value}
            onChange={onChange}
            inputProps={{ 'aria-label': ariaLabel }}
            classes={{
                root: error ? commonClasses.themeColorError : "",
                colorPrimary: commonClasses.themeColorPrimary,
                error: commonClasses.themeColorError
            }}
        />
    )
})


CustomCheckbox.defaultProps = {
    labelPlacement: "end",
    size: "medium",
    disableTypography: false
}


CustomCheckbox.propTypes = {
    name: PropTypes.string,
    ariaLabel: PropTypes.string,
    labelText: PropTypes.string,
    labelPlacement: PropTypes.oneOf(['end', 'start', 'top', 'bottom']),
    size: PropTypes.oneOf(["small", "medium", "large"]),
    checked: PropTypes.bool,
    disabled: PropTypes.bool,
    disableTypography: PropTypes.bool,
    value: PropTypes.any,
    error: PropTypes.bool,
    onChange: PropTypes.func
}

export default React.memo(CustomCheckbox)