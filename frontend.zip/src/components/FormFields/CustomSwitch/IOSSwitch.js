import React from 'react'
import classNames from 'classnames'
import PropTypes from "prop-types";
import { Field } from 'formik';
import { FormControlLabel, Tooltip, FormHelperText } from '@mui/material';
import { Switch } from 'formik-mui';
// *** styles ***
import commonStyles from 'assets/styles/components/FormFields/common.styles'
import { styled } from '@mui/material/styles';
import { useTheme, createUseStyles } from 'react-jss'
import { iOSCustomSwitcherStyles } from 'assets/styles/components/FormFields/customSwitch.styles'
const useCommonStyles = createUseStyles(commonStyles)


const IOSSwitch = styled(({ checked, sysTheme, error, ...props }) => (
    <Tooltip title={Boolean(checked) ? "checked" : "unchecked"}>
        <span>
            <Switch
                sx={{ mr: 1 }}
                focusVisibleClassName=".Mui-focusVisible"
                checked={checked}
                // disableRipple
                {...props}
            />
        </span>
    </Tooltip>
))(iOSCustomSwitcherStyles);


function IOSCustomSwitcher({ name, label, checked, disabled, required, error, helperText, onChange }) {
    const theme = useTheme()
    const commonClasses = useCommonStyles()

    // console.log("=================================================");
    // console.log(`%c --- Render IOSCustomSwitcher: ${name}`, "color: #8aa1ef");
    // console.log("=================================================");

    // console.log("label: ", label);
    // console.log("checked: ", checked);
    // console.log("=================================================");

    return (
        <>
            <FormControlLabel
                label={required ? `${label} *` : label}
                sx={{ m: 0 }}
                classes={{
                    label: error ? commonClasses.themeColorError : ""
                }}
                control={
                    <Field
                        disabled={disabled}
                        type="checkbox"
                        name={name}
                        label={label}
                        checked={checked}
                        error={error}
                        sysTheme={theme}
                        component={IOSSwitch}
                        onChange={onChange}
                    />
                }
            />
            {
                helperText && (
                    <FormHelperText
                        error={error}
                        classes={{
                            root: classNames(commonClasses.helperText, { [commonClasses.themeColorSuccess]: !error }),
                            error: commonClasses.themeColorError
                        }}
                    >
                        {helperText}
                    </FormHelperText>
                )
            }
        </>
    )
}


IOSCustomSwitcher.defaultProps = {
    required: false
}


IOSCustomSwitcher.propTypes = {
    name: PropTypes.string,
    label: PropTypes.string,
    checked: PropTypes.bool,
    disabled: PropTypes.bool,
    required: PropTypes.bool,
    error: PropTypes.bool,
    onChange: PropTypes.func
}

export default React.memo(IOSCustomSwitcher)