import { memo, useState, useEffect, useCallback, useContext } from 'react'
import PropTypes from 'prop-types'
import { FilterContext } from '../index'
import { Zoom, IconButton } from '@mui/material';
import Datepicker from 'components/FormFields/Datepicker'
import useFilterText from 'hooks/useFilterText'
import moment from 'moment';
//*** Icons ***
import CloseIcon from '@mui/icons-material/Close';
//*** styles ***
const extraThemeComponents = {
    components: {
        MuiInputBase: {
            styleOverrides: {
                root: {
                    "& > .MuiButtonBase-root": {
                        order: 1,
                        padding: 0,
                    },
                    "& > div": {
                        order: 1,
                        marginLeft: 0,
                    },
                },
            },
        },
    }
}


function DateColumnFilter({ column: { filterValue, preFilteredRows, setFilter, filterTextVariant, filterTextToDisplay } }) {

    const filterContextConsumer = useContext(FilterContext)
    const [value, setValue] = useState(filterValue || '');
    const [clearIconIsVisible, setClearIconIsVisible] = useState(false)
    const [labelText] = useFilterText(
        filterTextVariant ? filterTextVariant : "",
        filterTextToDisplay ? filterTextToDisplay : "",
        preFilteredRows.length ? preFilteredRows.length : 0
    )

    // TODO: reset filter value when data table is resetting all filters
    useEffect(() => { if (filterContextConsumer) setValue('') }, [filterContextConsumer])


    const onDateChange = useCallback(value => {
        const date = Boolean(value) ? new Date(value) : value
        setFilter(moment(date).format("MM/DD/YYYY"))
        setValue(moment(date).format("MM/DD/YYYY"))
        setClearIconIsVisible(true)
    }, [filterValue])


    const clearFilter = useCallback(() => {
        const date = Date.now();
        setFilter(undefined)
        setValue(moment(date).format("MM/DD/YYYY"))
        setClearIconIsVisible(false)
    }, [filterValue])

    return (
        <Datepicker
            label={labelText}
            format='MM/dd/yyyy'
            value={value}
            onDateChange={onDateChange}
            fullWidth
            extraThemeComponents={extraThemeComponents.components}
            withoutDateValidation
            trackValueChanges
            startAdornment={
                <Zoom
                    in={clearIconIsVisible}
                    timeout={400}
                >
                    <IconButton
                        disableRipple
                        onClick={clearFilter}
                    >
                        <CloseIcon />
                    </IconButton>
                </Zoom>
            }
        />
    )

}


DateColumnFilter.propTypes = {
    column: PropTypes.object.isRequired
}

export default memo(DateColumnFilter)
