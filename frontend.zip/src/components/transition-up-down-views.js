import { memo, Fragment } from 'react'
import PropTypes from 'prop-types';
import classNames from 'classnames';
// *** styles ***
import { createUseStyles } from 'react-jss';
import styles from 'assets/styles/components/transitionUpDownViews.styles';
const useStyles = createUseStyles(styles)



/**
 * @author Na'oum Haddad <mailto:e.naoumhaddad@outlook.com> 
 * @type {Predicate}
 * TODO: transition 2-views up and down inside page
 * 
 * * open: define the current direction of component is "UP" or "DOWN"
 * * inProgress: attribute that used to keep (view-2) alive until (view-1) is loaded and transition is end
 */
function TransitionUpDownViews({ open, inProgress, children }) {
    const classes = useStyles()
    return (
        <div className={classNames(classes.transitionUpDownPage, {
            "is-open": open,
            "transition-in-progress": inProgress
        })}>
            {children}
        </div>
    )
}

TransitionUpDownViews.defaultProps = {
    open: false,
    inProgress: false,
    children: <Fragment />
}

TransitionUpDownViews.propTypes = {
    open: PropTypes.bool,
    inProgress: PropTypes.bool,
    children: PropTypes.any
}





export default memo(TransitionUpDownViews)