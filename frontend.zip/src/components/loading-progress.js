import { memo } from 'react'
import { CircularProgress, Typography } from '@mui/material';
// *** styles ***
import { createUseStyles } from 'react-jss';
import styles from 'assets/styles/components/loadingProgress.styles';
const useStyles = createUseStyles(styles)


function LoadingProgress() {
  const classes = useStyles()
  return (
    <div className={classes.loadingProgress}>
      <CircularProgress className="progress" />
      <Typography>Please wait . . .</Typography>
    </div >
  )
}

export default memo(LoadingProgress)