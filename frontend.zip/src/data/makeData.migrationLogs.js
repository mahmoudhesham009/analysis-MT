import moment from 'moment';
import namor from 'namor'
import { randomDates, range } from './common';



const statusErrors = [
    500, 404, 400, 401, 200
]


const newRecord = () => {
    return {
        id: Math.floor(Math.random() * 1000),
        cloneProcessId: namor.generate({ words: 1, saltLength: 0 }),
        name: namor.generate({ words: 1, saltLength: 0 }),
        status: statusErrors[Math.floor(Math.random() * (statusErrors.length - 1 - 0 + 1) + 0)],
        lastUpdateDate: moment(randomDates[Math.floor(Math.random() * (randomDates.length - 1))]).format("mm/DD/yyyy"),
        projectNum: `#${namor.generate({ words: 0, saltLength: 5 })}`,
        errorMSG: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.",
        validate: Math.floor(Math.random() * 1000) % 2 === 0
    }
}


export default function makeData(...lens) {
    const makeDataLevel = (depth = 0) => {
        const len = lens[depth]
        return range(len).map(d => {
            return {
                ...newRecord(),
                subRows: lens[depth + 1] ? makeDataLevel(depth + 1) : undefined,
            }
        })
    }

    return makeDataLevel()
}
