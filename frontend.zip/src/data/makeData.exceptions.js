import namor from 'namor'
import { range } from './common';



const newRecord = () => {
    return {
        id: Math.floor(Math.random() * 1000),
        jobId: 445,
        // jobId: Math.floor(Math.random() * 1000),
        processInstanceId: namor.generate({ words: 1, saltLength: 0 }),
        projectNum: namor.generate({ words: 1, saltLength: 0 }),
    }
}


export default function makeData(...lens) {
    const makeDataLevel = (depth = 0) => {
        const len = lens[depth]
        return range(len).map(d => {
            return {
                ...newRecord(),
                subRows: lens[depth + 1] ? makeDataLevel(depth + 1) : undefined,
            }
        })
    }

    return makeDataLevel()
}