import { memo, createContext, useState, useEffect, useMemo, useCallback } from 'react'
import queryString from 'query-string';
import { Link, useLocation, useNavigate } from 'react-router-dom';
// *** views ***
import ErrorPage from 'views/errorPage';
// *** components ***
import TransitionUpDown from 'components/transition-up-down-views';
import FindProcessCard from 'components/views/add-exception/find-process-card';
import DeploymentList from 'components/views/analysis/deployment-list';
// *** hooks ***
import useNavigatingAway from "hooks/useNavigatingAway";
import useEventListener from 'hooks/useEventListener';
// *** redux ***
import { useDispatch } from 'react-redux'
import {
    ChangeExpandedParentAccordion,
    ChangeExpandedChildAccordion
} from '@redux'
// *** config ***
import PtoResponse from 'config/exception-dynamic-form.json'; // for demo only
import ProcessApi from 'config/process-api'

export const AddExceptionNavigatingAwayContext = createContext()
function AddException() {
    const navigate = useNavigate()
    const dispatch = useDispatch()
    const location = useLocation();
    const parsed = queryString.parse(location.search);
    /**
     * States
     */
    const [analysisSectionIsOpen, setAnalysisSectionIsOpen] = useState(false)
    const [analysisSectionRevertInProgress, setAnalysisSectionRevertInProgress] = useState(false)
    const [loading, setLoading] = useState(true)
    const [deployments, setDeployments] = useState([])
    const [processInfo, setProcessInfo] = useState({})
    const [errorOccurred, setErrorOccurred] = useState("")
    const [processInstanceId, setProcessInstanceId] = useState("")
    const [projectNum, setProjectNum] = useState("")
    const [fpsIsLoading, setFpsIsLoading] = useState(false)
    const [canShowDialogLeavingPage, setCanShowDialogLeavingPage] = useState(false);
    const [hardReload, setHardReload] = useState(false)
    /**
     * Hooks
     */
    const [showDialogLeavingPage, confirmNavigation, cancelNavigation] = useNavigatingAway(analysisSectionIsOpen && !hardReload);


    const isLocatedToAnalysisSectionDirectly = useMemo(() => {
        return (parsed?.jobID && parsed?.projectNumber && location.hash === "#deployments") ||
            (parsed?.jobID && parsed?.processInstanceId && location.hash === "#deployments") ? true : false
    }, [])


    const onBeforeunload = useCallback((e) => {
        setErrorOccurred("")
    }, []);

    useEffect(() => {
        window.addEventListener("beforeunload", onBeforeunload);
        return () => {
            window.removeEventListener("beforeunload", onBeforeunload);
        };
    }, [onBeforeunload])

    useEffect(() => {
        if (isLocatedToAnalysisSectionDirectly) {
            setFpsIsLoading(true)
            setAnalysisSectionIsOpen(true)
            setAnalysisSectionRevertInProgress(true)
        }
    }, [isLocatedToAnalysisSectionDirectly])

    const onPopState = () => {

        setLoading(false)
        if (!analysisSectionIsOpen) {
            navigate(`/add-exception?jobID=${parsed?.jobID}`, { replace: true })
            dispatch(ChangeExpandedParentAccordion(null))
            dispatch(ChangeExpandedChildAccordion(null))            
        }

        if (!canShowDialogLeavingPage && analysisSectionIsOpen) {
            // Go Back to FindProcessCar
            cancelNavigation()            
            setCanShowDialogLeavingPage(false)
            setFpsIsLoading(false)
            setTimeout(() => {
                setAnalysisSectionIsOpen(false)
                setLoading(true)
                setDeployments([])
                setAnalysisSectionRevertInProgress(false)
                setTimeout(() => {
                    navigate(`/add-exception?jobID=${parsed?.jobID}`, { replace: true })
                }, 200)
            }, 300);
        }
    }

    useEventListener("popstate", onPopState)


    const onConfirmNavigation = useCallback(() => {
        cancelNavigation()
        setDeployments([])
        setAnalysisSectionIsOpen(false)
        setTimeout(() => {
            setCanShowDialogLeavingPage(false)
            setAnalysisSectionRevertInProgress(false)
            setFpsIsLoading(false)
        }, 500);
    }, [])

    const openAnalyticsPage = (responseData, processInstanceId, projectNum) => {
        const selectedNode = processInstanceId ? `processInstanceId=${processInstanceId}` : `projectNumber=${projectNum}`
        navigate(`/add-exception?jobID=${parsed?.jobID}&${selectedNode}#deployments`, { replace: true })

        setProcessInstanceId(processInstanceId)
        setProjectNum(projectNum)
        setAnalysisSectionIsOpen(true)
        setAnalysisSectionRevertInProgress(true)

        if (!process.env.NODE_ENV || process.env.NODE_ENV === 'development') {
            //?=================[ DEV ]========================            
            setTimeout(() => {
                const processedApi = ProcessApi({ backendResponse: PtoResponse, type: "add-exception" })
                setLoading(false)
                setDeployments(processedApi.result)
                setProcessInfo(processedApi.processInfo)
            }, 2000)
        }
        else {
            //?================= PROD ========================            
            setTimeout(() => {

                const deploymentsArePresent = Array.isArray(responseData?.deployments) && responseData?.deployments?.length > 0

                if (deploymentsArePresent) {
                    const processedApi = ProcessApi({ type: "add-exception", backendResponse: responseData })
                    setDeployments(processedApi.result)
                    setProcessInfo(processedApi.processInfo)
                }
                else {
                    setProcessInfo(Boolean(responseData?.processInfo) ? responseData?.processInfo : {})
                }
                setLoading(false)
            }, 2000)
        }
    }


    const onFindProcessCardError = error => {
        if(isLocatedToAnalysisSectionDirectly){
            setFpsIsLoading(false)
            setAnalysisSectionIsOpen(false)
            setAnalysisSectionRevertInProgress(false)
            setErrorOccurred(error)
        }
    }

    if (!Boolean(parsed?.jobID)) return (
        <ErrorPage
            errorMessage="Oops!&nbsp;&nbsp;<strong>[ Job ID ]</strong>&nbsp;&nbsp;is not present."
            extraJSX={
                <Link to="/">
                    Back to Homepage
                </Link>
            }
        />
    )
    else if (Boolean(errorOccurred)) return (
        <ErrorPage
            errorMessage="Something went wrong while fetching data!"
            extraJSX={<code>{errorOccurred}</code>}
        />
    )
    else return (
        <TransitionUpDown
            open={analysisSectionIsOpen}
            inProgress={analysisSectionRevertInProgress}
        >
            <section id="find-process">
                <FindProcessCard
                    jobID={parsed?.jobID}
                    fpsIsLoading={fpsIsLoading}
                    setFpsIsLoading={setFpsIsLoading}
                    openAnalyticsPage={openAnalyticsPage}
                    onError={onFindProcessCardError}
                />
            </section>
            <section id="analysis">
                <AddExceptionNavigatingAwayContext.Provider value={{
                    canShowDialogLeavingPage,
                    showDialogLeavingPage: showDialogLeavingPage && canShowDialogLeavingPage,
                    confirmNavigation: onConfirmNavigation,
                    cancelNavigation,
                    setCanShowDialogLeavingPage,
                    setHardReload
                }}>
                    <DeploymentList
                        loading={loading}
                        deployments={deployments}
                        processInfo={processInfo}
                        jobID={parsed?.jobID}
                        viewType="add-exception"
                        processInstanceId={processInstanceId}
                        projectNum={projectNum}
                    />
                </AddExceptionNavigatingAwayContext.Provider>
            </section>
        </TransitionUpDown>
    )
}

export default memo(AddException)
