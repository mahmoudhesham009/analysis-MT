// TODO : generate label text for data table columns based on variant.
// TODO : change label text for any column filter depending on variant actions.
import { useReducer, useEffect, useContext } from 'react'
import PropTypes from 'prop-types'
import { WindowContext } from 'App'

//! variant actions
const DT_FILTER_LBL_AS_IS = 'AS_IS';
const DT_FILTER_LBL_NUMBER_OF_RECORDS = 'NUMBER_OF_RECORDS'
const DT_FILTER_LBL_PRE_TEXT_POST_NUMBER = 'PRE_TEXT_POST_NUMBER'
const DT_FILTER_LBL_PRE_NUMBER_POST_TEXT = 'PRE_NUMBER_POST_TEXT'


const initialState = { labelText: "" }

const reducer = (state, action) => {
    switch (action.variant) {
        case DT_FILTER_LBL_AS_IS:
            return { labelText: action.text }
        case DT_FILTER_LBL_NUMBER_OF_RECORDS:
            return { labelText: action.windowWidth < 1280 ? action.number : `Search ${action.number} records...` }
        case DT_FILTER_LBL_PRE_TEXT_POST_NUMBER:
            return { labelText: `${action.text} ${action.number}` }
        case DT_FILTER_LBL_PRE_NUMBER_POST_TEXT:
            return { labelText: `${action.number} ${action.text}` }            
        default:
            return state;
    }
}

function useFilterText(variant = "", filterTextToDisplay = "", number = 0) {
    const [state, dispatch] = useReducer(reducer, initialState)
    const { windowWidth } = useContext(WindowContext)

    useEffect(() => {
        dispatch({
            variant: variant,
            text: filterTextToDisplay,
            number: number,
            windowWidth: windowWidth
        })
    }, [variant, filterTextToDisplay, number, windowWidth])


    return [state.labelText, dispatch]
}


useFilterText.propTypes = {
    variant: PropTypes.oneOf([
        DT_FILTER_LBL_AS_IS,
        DT_FILTER_LBL_NUMBER_OF_RECORDS,
        DT_FILTER_LBL_PRE_TEXT_POST_NUMBER,
        DT_FILTER_LBL_PRE_NUMBER_POST_TEXT
    ]),
    filterTextToDisplay: PropTypes.string,
    number: PropTypes.number
}


export {
    DT_FILTER_LBL_AS_IS,
    DT_FILTER_LBL_NUMBER_OF_RECORDS,
    DT_FILTER_LBL_PRE_TEXT_POST_NUMBER,
    DT_FILTER_LBL_PRE_NUMBER_POST_TEXT    
}

export default useFilterText