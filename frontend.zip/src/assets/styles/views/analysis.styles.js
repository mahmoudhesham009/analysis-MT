import { transparentize } from "polished"

const AnalysisStyles = theme => ({
    analysis: {
        "& .page-controls": {
            marginBottom: 25,
            "& .add-exception-button": {
                backgroundColor: theme.colors.primary[0],
                paddingLeft: 6,
                paddingRight: 10,
                // marginBottom: 25,
                boxShadow: "unset",
                "& svg": {
                    verticalAlign: "middle",
                    marginTop: -3,
                    paddingRight: 5
                },
            }
        }
    }
})


const DeploymentListStyles = theme => ({
    accordionSummaryRoot: {
        "& p": {
            flexShrink: 0,
            // backgroundColor: theme.colors.primary[0],
            borderRadius: 60,
            padding: "8px 16px",
            "& button": {
                pointerEvents: "none",
                verticalAlign: "middle",
                padding: 0,
                marginRight: 8,
                // color: theme.colors.white
            },
            "& strong": {
                display: "inline-block",
                verticalAlign: "bottom",
                // color: theme.colors.white
            }
        }
    },
    InfoLabel: {
        display: "inline-block",
        padding: 15,
        marginBottom: 15,
        borderRadius: 3,
        backgroundImage: "linear-gradient(to left top, #003660, #005780, #007787, #009574);",
        position: "relative",
        "&:before": {
            content: "''",
            position: "absolute",
            top: 0,
            left: 0,
            width: "100%",
            height: "100%",
            borderRadius: 3,
            backgroundColor: transparentize(0.9, theme.colors.black),
        },
        "& h1": {
            color: theme.colors.white,
            position: "relative",
            zIndex: 1,
            fontSize: 24,
            maxWidth: 600,
            width: "fit-content",
            whiteSpace: "nowrap",
            textOverflow: "ellipsis",
            overflow: "hidden",
        }
    }
})


export { DeploymentListStyles }
export default AnalysisStyles