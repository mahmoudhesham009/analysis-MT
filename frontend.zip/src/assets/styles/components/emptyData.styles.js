const EmptyDataStyles = theme => ({
    emptyDataRoot: {
        height: "calc(100vh - 64px)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        flexDirection: "column",
        textAlign: "center",
        "& svg": {
            fontSize: "7em",
            color: theme.colors.primary[0]
        },
        "& h4": {
            fontSize: "1.5em",
            margin: 0,
            fontWeight: "300",
            color: theme.colors.primary[0]
        },
        "& button": {
            marginTop: 15,
            boxShadow: "unset",
            color: theme.colors.primary[0],
            borderColor: theme.colors.primary[0],
            padding: "5px 10px",
            "& svg": {
                marginRight: 5,
                color: theme.colors.primary[0],
                fontSize: 20,
                transition: "margin .09s linear"
            },
            "&:hover": {
                backgroundColor: theme.colors.primary[0],
                color: theme.colors.white,
                borderColor: theme.colors.primary[0],
                "& svg": {
                    color: theme.colors.white,
                    marginRight: 10,
                }
            }
        }
        // "& a": {
        //     marginTop: 15
        // }
    }
})


export default EmptyDataStyles
