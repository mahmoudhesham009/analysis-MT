import { alpha } from '@mui/material/styles';

const CustomInputStyle = theme => ({
    disabled: {
        "&:before": {
            backgroundColor: "transparent !important"
        }
    },
    underline: {
        "&:hover:not($disabled):before,&:before": {
            borderColor: theme.colors.gray[4] + " !important",
            borderWidth: "1px !important"
        },
        "&:after": {
            borderColor: theme.colors.primary[0] + "!important"
        }
    },
    underlineError: {
        "&:after": {
            transform: "scaleX(1)",
            borderColor: theme.colors.danger[0] + "!important"
        }
    },
    labelRoot: {
        ...theme.fonts.default,
        color: theme.colors.gray[3] + " !important",
        fontWeight: "400",
        fontSize: "14px",
        lineHeight: "1.42857",
        letterSpacing: "unset"
    },
    feedback: {
        position: "absolute",
        top: "18px",
        right: "0",
        zIndex: "2",
        display: "block",
        width: "24px",
        height: "24px",
        textAlign: "center",
        pointerEvents: "none"
    },
    marginTop: {
        marginTop: "16px"
    },
    formControl: {
        paddingBottom: "10px",
        // margin: "27px 0 0 0",
        position: "relative",
        verticalAlign: "unset"
    }
})







const RedditTextFieldStyles = ({ theme, systemTheme }) => {
    return ({
        "& .MuiFormLabel-root": {
            '&.Mui-focused': {
                color: systemTheme.colors.primary[0]
            },
            '&.Mui-error': {
                color: systemTheme.colors.danger[0],
            }
        },
        '& .MuiFilledInput-root': {
            border: `1px solid rgba(0, 0, 0, 0.6)`,
            overflow: 'hidden',
            borderRadius: 4,
            backgroundColor: systemTheme.colors.white,
            transition: theme.transitions.create([
                'border-color',
                'background-color',
                'box-shadow',
            ]),
            '&:hover': {
                borderColor: systemTheme.colors.primary[0],
                backgroundColor: systemTheme.colors.white,
            },
            '&.Mui-focused': {
                borderColor: systemTheme.colors.primary[0],
                backgroundColor: systemTheme.colors.white,
                boxShadow: `${alpha(systemTheme.colors.primary[0], 0.25)} 0 0 0 2px`,
            },
            '&.Mui-error': {
                color: systemTheme.colors.danger[0],
                borderColor: systemTheme.colors.danger[0],
                boxShadow: `${alpha(systemTheme.colors.danger[0], 0.25)} 0 0 0 2px`,
            }
        },
    })
}

export { RedditTextFieldStyles }
export default CustomInputStyle
