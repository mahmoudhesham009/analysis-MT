
const FloatingActionButtonStyles = {
    extendedIcon: {
        marginRight: 16
    },
    middleIcon: {
        "& *": {
            verticalAlign: "middle"
        }
    }
}


export default FloatingActionButtonStyles